
/* 
 *  !! OIY OIY !!
 *
 *  The purpose of this file is only to get pjlib-util-test linked. I haven't
 *  actually tried to run pjlib-util-test on RTEMS!!
 *
 */


#include "../../pjlib/src/pjlib-test/main_rtems.c"
